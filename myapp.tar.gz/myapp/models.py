from django.db import models


# Create your models here.
class GuruDB(models.Model):
    Company_Name = models.CharField(max_length=100, blank=True)
    Email_Address = models.EmailField(blank=True)
    Contact_Full_Name = models.CharField(max_length=100, blank=True)
    Contact_Job_Title = models.CharField(max_length=100, blank=True)
    Phone_Number = models.CharField(max_length=13, blank=True)
    Fax_Number = models.CharField(max_length=13, blank=True)
    Address = models.CharField(max_length=100, blank=True)
    Address_2 = models.CharField(max_length=100, blank=True)
    Address_3 = models.CharField(max_length=100, blank=True)
    Town = models.CharField(max_length=100, blank=True)
    County = models.CharField(max_length=100, blank=True)
    Postcode = models.CharField(max_length=100, blank=True)
    Region = models.CharField(max_length=100, blank=True)
    Country = models.CharField(max_length=100, blank=True)
    SIC_Code = models.CharField(max_length=100, blank=True)
    Business_Category = models.CharField(max_length=100, blank=True)
    Web_Address = models.CharField(max_length=100, blank=True)
    Valid_Email = models.BooleanField(default=False)
    Valid_Site = models.BooleanField(default=False)
    Site_Type = models.IntegerField(default=0)  # 1 = wp 2 = dp, 3 = mg , 4 = others
    Is_Checked = models.BooleanField(default=False)

    # Black_List = models.BooleanField(default=False)

    def __str__(self):
        return self.Company_Name + " " + self.Contact_Full_Name


class CompanyList(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

''' 
class Drupal(models.Model):
    gg_fk = models.OneToOneField(GuruDB, on_delete=models.CASCADE)
    is_drupal = models.BooleanField(default=False)
'''
"""
Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
Region	Country  SIC_Code	Business_Category	Web_Address
"""
