from django.contrib import admin

# Register your models here.
from myapp.models import GuruDB, CompanyList

admin.site.register(GuruDB)
# admin.site.register(MyCount)


admin.site.register(CompanyList)
