import os

from myapp.models import GuruDB, CompanyList
import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry
from django.http import HttpResponse


def requests_retry_session(
        retries=1,
        backoff_factor=0.3,
        status_forcelist=(404, 500, 502, 504),
        session=None,
):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session


def is_magento(site):
    url = 'http://' + str(site)  # str(i['Web_Address'])
    count = 0
    try:
        r = requests.get(url)
        for line in r:
            for part in line.split():
                if "magento" in part.decode():
                    count = count + 1
                    print("mg ok")
                    return True
    except Exception as x:
        print("exception!" + str(x))
        return False
    print("not ok")
    return False


def is_wordpress(site):
    url = 'http://' + str(site) + '/wp-login.php'
    try:
        response = requests_retry_session().get(
            url,
            timeout=5
        )
    except Exception as x:
        print('Not wordpress :(', x.__class__.__name__)
        return False
    else:
        print("wp ok")
        return True


def is_drupal1(site):
    url = 'http://isthissitebuiltwithdrupal.com/http://' + str(site)  # str(i['Web_Address'])
    # count = 0
    try:
        r = requests.get(url)
        for line in r:
            for part in line.split():
                if "yes" in part.decode():
                    # count = count + 1
                    print("dp1 ok")
                    return True
    except Exception as x:
        print("exception!" + str(x))
        return False
    print("dp1 not ok")
    return False


def is_drupal2(site):
    url = 'http://' + str(site)  # str(i['Web_Address'])
    count = 0
    try:
        r = requests.get(url)
        for line in r:
            for part in line.split():
                if "drupal" in part.decode():
                    print(part)
                    count = count + 1
                    print("dp2 ok")
                    return True
    except Exception as x:
        print("exception!" + str(x))
        return False
    print("dp2 not ok")
    return False


def is_drupal(site):
    url = 'http://' + str(site) + '/user'
    # t0 = time.time()
    try:
        response = requests_retry_session().get(
            url,
            timeout=5
        )
    except Exception as x:
        print('It failed :(', x.__class__.__name__)
    else:
        if is_drupal1(site):
            return True
        elif is_drupal2(site):
            return True
    return False


'''
 
def is_drupal(site):
    url = 'http://' + str(site) + '/user/password'
    try:
        response = requests_retry_session().get(
            url,
            timeout=5
        )
    except Exception as x:
        print('Not drupal :(', x.__class__.__name__)
        return False
    else:
        print("dp ok")
        return True
'''


def detect_drupal(request):
    # gurudb = GuruDB.objects.filter(pk__range=[641, 1306])
    gurudb = GuruDB.objects.all()[20:25]
    for i in gurudb:
        url = 'http://' + str(i.Web_Address) + '/user/password'
        # t0 = time.time()
        try:
            print(i.pk)
            response = requests_retry_session().get(
                url,
                timeout=5
            )
        except Exception as x:
            print('It failed :(', x.__class__.__name__)
        else:
            try:
                # temp = Drupal.objects.create(gg_fk=i, is_drupal=True)
                i.Site_Type = 2
                i.save()
                print('ok')
            except Exception as x:
                print(x)

    # transaction.commit()
    try:
        os.system('spd-say "your program has finished"')
    except Exception as x:
        print(x)
    return HttpResponse('<h1>ok! DP sites confirmed!</h1>')
    # return None


def get_validate(email):
    return requests.get(
        "https://api.mailgun.net/v3/exclusivegroup.co.uk",
        auth=("api", "key-7512da59598befe580d52e26799b5bf9"),
        params={"address": str(email)})


''' 

def get_validate(email):
    return requests.get(
        "https://api.mailgun.net/v3/address/validate",
        auth=("api", "pubkey-5ogiflzbnjrljiky49qxsiozqef5jxp7"),
        params={"address": str(email)})

'''


def is_valid_site(site):
    url = 'http://' + str(site)
    try:
        response = requests_retry_session().get(
            url,
            timeout=5
        )
    except Exception as x:
        print('Invalid site :(', x.__class__.__name__)
        return False
    else:
        return True


def cross_check1(request):
    gurudb = GuruDB.objects.filter(Is_Checked=True)
    for i in gurudb:
        site = str(i.Company_Name)
        cnt = 0
        cnt = CompanyList.objects.filter(name=site).count()
        if cnt > 0:
            print(False)
            i.Valid_Email = False
            i.Valid_Site = False
            i.Site_Type = 0
            i.save()
    print(True)
    return HttpResponse('<h1>Ok done!</h1>')


def cross_check(site):
    cnt = 0
    cnt = CompanyList.objects.filter(name=site).count()
    print(site+" "+str(cnt))
    if cnt > 0:
        return False
    return True


def analyse(request):
    # cross_check()
    gurudb = GuruDB.objects.filter(Site_Type=0).filter(Is_Checked=False)
    for i in gurudb:
        i.Is_Checked = True
        # validate mail
        print(i.pk)
        print(i.Email_Address)
        print(i.Web_Address)
        if cross_check(str(i.Company_Name)):
            b = False
            s = get_validate(i.Email_Address)
            if str(s) == "<Response [200]>":
                b = True
            i.Valid_Email = b
            if b:
                # validate site
                b1 = False
                b1 = is_valid_site(i.Web_Address)
                i.Valid_Site = b1

                # site type
                if is_wordpress(i.Web_Address):
                    i.Site_Type = 1
                elif is_drupal(i.Web_Address):
                    i.Site_Type = 2
                elif is_magento(i.Web_Address):
                    i.Site_Type = 3
                else:
                    i.Site_Type = 4
            i.save()
    return HttpResponse('<h1>ok! Job Done!</h1>')
