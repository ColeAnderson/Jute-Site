"""ShikderSite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.urls import path, include

from myapp import views, loaddata, analytics

app_name = 'myapp'

urlpatterns = [
    path('', views.home, name='home'),
    path('loaddata/', loaddata.load_data, name='load_data'),

    path('loaddata/csv_wordpress', loaddata.create_csv_wordpress, name='create_csv_wordpress'),
    path('loaddata/csv_drupal', loaddata.create_csv_drupal, name='create_csv_drupal'),
    path('loaddata/csv_magento', loaddata.create_csv_magento, name='create_csv_magento'),
    path('loaddata/csv_others', loaddata.create_csv_others, name='create_csv_others'),

    path('loaddata/csv_wordpress1', loaddata.create_csv_wordpress1, name='create_csv_wordpress1'),
    path('loaddata/csv_drupal1', loaddata.create_csv_drupal1, name='create_csv_drupal1'),
    path('loaddata/csv_magento1', loaddata.create_csv_magento1, name='create_csv_magento1'),
    path('loaddata/csv_others1', loaddata.create_csv_others1, name='create_csv_others1'),

    path('loaddata/valid_mailNotsite', loaddata.create_csv_validmailnotsite, name='validmailnotsite'),

    path('analytics/start/', analytics.analyse, name='analyse'),
    path('analytics/cross_check1/', analytics.cross_check1, name='cross_check1'),
    # ######################## Donot use ###########################################################
    path('load_company/', loaddata.load_company, name='load_company'),
    path('analytics/dp/', analytics.detect_drupal, name='detect_drupal'),  # 2
]

'''     path('analytics/wp/', analytics.detect_wordpress, name='detect_wordpress'), # 1
    path('analytics/wp_emergency/', analytics.detect_wordpress_emergency, name='detect_wordpress_emergency'),  # 1
    path('analytics/dst/', analytics.detect_site_type, name='detect_site_type'),
     path('analytics/mg/', analytics.detect_magento, name='detect_magento'), # 3
    path('analytics/jl/', analytics.detect_joomla, name='detect_joomla'),  # 4

    path('analytics/isvalid/', analytics.detect_valid_addr, name='detect_valid_addr'),
    path('analytics/isvalid2/', analytics.detect_valid_addr2, name='detect_valid_addr2'),

    path('analytics/all_valid_sites/', analytics.all_valid_sites, name='all_valid_sites'),
    '''

