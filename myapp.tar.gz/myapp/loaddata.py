import os
import csv

from django.http import HttpResponse

from myapp.models import GuruDB, CompanyList

"""
Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
Region	Country  SIC_Code	Business_Category	Web_Address
"""


def load_data(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Database.csv'

    with open(DATA_PATH) as csvfile:
        try:
            reader = csv.DictReader(csvfile)
        except:
            return HttpResponse('<h1>Exception</h1>')
        i = 0
        failed = 0
        for row in reader:
            try:
                a = GuruDB(Company_Name=str(row['Company Name']), Email_Address=row['Email Address'],
                           Contact_Full_Name=str(row['Contact Full Name']),
                           Contact_Job_Title=str(row['Contact Job Title']),
                           Phone_Number=str(row['Phone Number']), Fax_Number=str(row['Fax Number'])
                           , Address=str(row['Address']), Address_2=str(row['Address 2']),
                           Address_3=str(row['Address 3']),
                           Town=str(row['Town']), County=str(row['County']), Postcode=str(row['Postcode']),
                           Region=str(row['Region']),
                           Country=str(row['Country']), SIC_Code=str(row['SIC Code'])
                           , Business_Category=str(row['Business Category']), Web_Address=str(row['Web Address'])
                           ,
                           # Valid_Email=False,
                           # Valid_Site=False,
                           # Site_Type=0
                           )
                a.save()
                i = i + 1
                print(i)
            except Exception as x:
                failed = failed + 1
                print(x)
                # print(i, row['Company Name'], row['Email Address'], row['Web Address'])
        print('Success: :' + str(i))
        print('failed :' + str(failed))
    csvfile.close()
    try:
        os.system('spd-say "your program has finished"')
    except Exception as x:
        print(x)
    return HttpResponse('<h1>ok!</h1>')


def load_company(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/index-300.csv'

    with open(DATA_PATH) as csvfile:
        try:
            reader = csv.DictReader(csvfile)
        except:
            return HttpResponse('<h1>Exception</h1>')
        i = 0
        failed = 0
        for row in reader:
            try:
                a = CompanyList(name=str(row['Company name']))
                a.save()
                i = i + 1
                print(i)
            except Exception as x:
                failed = failed + 1
                print(x)
                # print(i, row['Company Name'], row['Email Address'], row['Web Address'])
        print('Success: :' + str(i))
        print('failed :' + str(failed))
    csvfile.close()
    try:
        os.system('spd-say "your program has finished"')
    except Exception as x:
        print(x)
    return HttpResponse('<h1>ok!</h1>')


def create_csv_drupal(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Drupal.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Site_Type=2)
    temp = temp.filter(Email_Address__endswith='com')
    temp = temp.filter(Web_Address__endswith='com')
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')


def create_csv_wordpress(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Wordpress.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Site_Type=1)
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
       Valid_Email
    Valid_Site
    Site_Type 

           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')


def create_csv_magento(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Magento.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Site_Type=3)
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
       Valid_Email
    Valid_Site
    Site_Type 

           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')


def create_csv_others(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Others.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Site_Type=4)
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
       Valid_Email
    Valid_Site
    Site_Type 

           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')


################################################################################

def create_csv_drupal1(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Drupalcouk.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Site_Type=2)
    temp = temp.filter(Email_Address__endswith='co.uk')
    temp = temp.filter(Web_Address__endswith='co.uk')
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')


def create_csv_wordpress1(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Wordpresscouk.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Site_Type=1)
    temp = temp.filter(Email_Address__endswith='co.uk')
    temp = temp.filter(Web_Address__endswith='co.uk')
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
       Valid_Email
    Valid_Site
    Site_Type 

           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')


def create_csv_magento1(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Magentocouk.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Site_Type=3)
    temp = temp.filter(Email_Address__endswith='co.uk')
    temp = temp.filter(Web_Address__endswith='co.uk')
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
       Valid_Email
    Valid_Site
    Site_Type 

           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')


def create_csv_others1(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/Otherscouk.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Site_Type=4)
    temp = temp.filter(Email_Address__endswith='co.uk')
    temp = temp.filter(Web_Address__endswith='co.uk')
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
       Valid_Email
    Valid_Site
    Site_Type 

           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')


def create_csv_validmailnotsite(request):
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_PATH = BASE_DIR + '/ValidMailNotSite.csv'
    csvoutput = open(DATA_PATH, 'w')
    writer = csv.writer(csvoutput, lineterminator='\n')
    temp = GuruDB.objects.filter(Valid_Email=True, Valid_Site=False)
    all = []
    for i in temp:
        row = []
        """
       Company_Name	Email_Address	Contact_Full_Name	Contact_Job_Title	Phone_Number
       Fax_Number	Address	Address_2	Address_3	Town	County	Postcode
       Region	Country  SIC_Code	Business_Category	Web_Address
       Valid_Email
    Valid_Site
    Site_Type 

           """
        row.append(i.Company_Name)
        row.append(i.Email_Address)
        row.append(i.Contact_Full_Name)
        row.append(i.Contact_Job_Title)
        row.append(i.Phone_Number)
        row.append(i.Fax_Number)
        row.append(i.Address)
        row.append(i.Address_2)
        row.append(i.Address_3)
        row.append(i.Town)
        row.append(i.County)
        row.append(i.Postcode)
        row.append(i.Region)
        row.append(i.Country)
        row.append(i.SIC_Code)
        row.append(i.Business_Category)
        row.append(i.Web_Address)
        all.append(row)
    writer.writerows(all)
    csvoutput.close()
    return HttpResponse('<h1>Done</h1>')
